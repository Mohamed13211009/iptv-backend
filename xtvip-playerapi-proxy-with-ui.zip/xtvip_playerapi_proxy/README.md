# XTVIP Proxy (player_api + stream)

## ماذا يفعل؟
- يستبدل استدعاءات المتصفح المباشرة لـ `player_api.php` بـ:
  - `GET /api/player_api?action=...`
- ويستبدل روابط التشغيل التي كانت تُظهر username/password بـ:
  - `GET /api/stream?type=vod|series|live&id=...&ext=...`

## تشغيل محليًا
```bash
npm install
cp .env.example .env
npm start
```
ثم افتح:
- http://localhost:3000

## على Railway
- ارفع المشروع
- ضع Variables: SUB_BASE_URL, SUB_USERNAME, SUB_PASSWORD
- افتح /debug/env للتأكد أنها متسجلة
