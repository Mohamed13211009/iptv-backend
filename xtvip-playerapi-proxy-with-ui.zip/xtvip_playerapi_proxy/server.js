/**
 * XTVIP Secure Proxy (Express)
 * Exposes:
 *  - GET /api/player_api?action=...
 *  - GET /api/stream?type=vod|series|live&id=...&ext=...
 * Keeps subscription creds on server via ENV.
 */

import express from "express";
import fetchPkg from "node-fetch";

const fetchFn = globalThis.fetch ?? fetchPkg;

const app = express();
app.disable("x-powered-by");

app.use((req, res, next) => {
  res.setHeader("X-Frame-Options", "DENY");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.setHeader("Referrer-Policy", "no-referrer");
  res.setHeader("Permissions-Policy", "geolocation=(), microphone=(), camera=()");
  // CSP: no third-party scripts/frames (helps block ad injection)
  res.setHeader(
    "Content-Security-Policy",
    "default-src 'self'; script-src 'self'; object-src 'none'; frame-src 'none'; base-uri 'self'; form-action 'self'; img-src 'self' https: data:; style-src 'self' 'unsafe-inline' https:; font-src 'self' https: data:; connect-src 'self';"
  );
  next();
});

const SUB_BASE_URL = process.env.SUB_BASE_URL; // e.g. https://xtvip.net
const SUB_USERNAME = process.env.SUB_USERNAME; // e.g. watch1235
const SUB_PASSWORD = process.env.SUB_PASSWORD; // e.g. 742837399

function assertEnv() {
  const missing = ["SUB_BASE_URL", "SUB_USERNAME", "SUB_PASSWORD"].filter(k => !process.env[k]);
  if (missing.length) throw new Error("Missing env vars: " + missing.join(", "));
}

function base() {
  return String(SUB_BASE_URL || "").replace(/\/$/, "");
}

app.get("/health", (req, res) => res.json({ ok: true }));

// Debug without exposing secrets
app.get("/debug/env", (req, res) => {
  res.json({
    hasBaseUrl: Boolean(process.env.SUB_BASE_URL),
    hasUser: Boolean(process.env.SUB_USERNAME),
    hasPass: Boolean(process.env.SUB_PASSWORD),
    baseUrlHost: (process.env.SUB_BASE_URL || "").replace(/^https?:\/\//, "").split("/")[0] || null
  });
});

// Proxy for Xtream Codes style player_api.php
app.get("/api/player_api", async (req, res) => {
  try {
    assertEnv();
    const action = String(req.query.action || "");
    const series_id = req.query.series_id ? String(req.query.series_id) : null;

    if (!action) return res.status(400).json({ error: "missing_action" });

    const url = new URL(base() + "/player_api.php");
    url.searchParams.set("username", SUB_USERNAME);
    url.searchParams.set("password", SUB_PASSWORD);
    url.searchParams.set("action", action);
    if (series_id) url.searchParams.set("series_id", series_id);

    const upstream = await fetchFn(url.toString(), {
      method: "GET",
      headers: {
        "Accept": "application/json, text/plain, */*",
        "User-Agent": "Mozilla/5.0 ProxyPlayerAPI/1.0",
      },
    });

    const ct = upstream.headers.get("content-type") || "application/json";
    res.status(upstream.status);
    res.setHeader("Content-Type", ct);
    const buf = Buffer.from(await upstream.arrayBuffer());
    res.send(buf);
  } catch (e) {
    res.status(500).json({ error: "player_api_failed", message: e?.message || String(e) });
  }
});

// Stream proxy: hides creds by streaming from upstream through this server.
app.get("/api/stream", async (req, res) => {
  try {
    assertEnv();
    const type = String(req.query.type || "vod"); // vod|series|live
    const id = String(req.query.id || "");
    const ext = String(req.query.ext || (type === "live" ? "m3u8" : "mp4"));

    if (!id) return res.status(400).json({ error: "missing_id" });

    // Map to upstream paths used by the original app:
    // vod -> /movie/user/pass/id.ext
    // series -> /series/user/pass/id.ext
    // live -> /live/user/pass/id.ext (often m3u8)
    const pathPrefix =
      type === "series" ? "series" :
      type === "live" ? "live" : "movie";

    const url = `${base()}/${pathPrefix}/${encodeURIComponent(SUB_USERNAME)}/${encodeURIComponent(SUB_PASSWORD)}/${encodeURIComponent(id)}.${encodeURIComponent(ext)}`;

    const upstream = await fetchFn(url, {
      method: "GET",
      headers: {
        "Accept": "*/*",
        "User-Agent": "Mozilla/5.0 ProxyStream/1.0",
      },
    });

    // Pass through status + content-type
    res.status(upstream.status);
    const ct = upstream.headers.get("content-type");
    if (ct) res.setHeader("Content-Type", ct);

    // Stream body
    const buf = Buffer.from(await upstream.arrayBuffer());
    res.send(buf);
  } catch (e) {
    res.status(500).json({ error: "stream_failed", message: e?.message || String(e) });
  }
});

// Serve the patched frontend
app.use(express.static("public", { extensions: ["html"] }));

const PORT = Number(process.env.PORT || 3000);
app.listen(PORT, () => console.log(`Listening on :${PORT}`));
